<?php 

namespace App\Helpers;

use Illuminate\Support\Facades\Auth;
use App\Models\Website;

class Helper {

    public static function getAddress()
    {
        $info = Website::find(1);
        return $info->address;
    }

    public static function getContactNumber()
    {
        $info = Website::find(1);
        return $info->contact_number;
    }

    public static function getFacebook()
    {
        $info = Website::find(1);
        return $info->facebook;
    }

    public static function getEmail()
    {
        $info = Website::find(1);
        return $info->email;
    }

    public static function getMap()
    {
        $info = Website::find(1);
        return $info->map;
    }


}