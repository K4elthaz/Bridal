<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

use App\Models\Customer;
use App\Models\Transaction;

class CustomerController extends Controller
{
    public function index() 
    {
        $page = [
            'name' =>  'Customers',
            'title' =>  'Customer Management',
            'crumb' =>  array('Customers' => '/customers')
        ];

        $customers = Customer::orderBy('full_name', 'ASC')->get();

        return view('customers.index', compact(
            'page',
            'customers',
        ));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'full_name' => 'required',
            'contact_number' => 'required',
            'address' => 'required'
        ]);

        try {
            DB::transaction(function() use ($request) {
                $customer = new Customer;
                $customer->full_name = $request->full_name;
                $customer->contact_number = $request->contact_number;
                $customer->address = $request->address;
                $customer->save();
            });

            return back()->withSuccess('Customer has been created successfully');

        } catch (\Exception $e) {
            return back()->withInput()->withErrors($e->getMessage());
        }
    }

    public function show(Request $request, $id)
    {
        $customer = Customer::find($id);
        if(!$customer) {
            return back()->withErrors('Customer doesn\'t exist');
        }

        $page = [
            'name' =>  'Customers',
            'title' =>  'Show Customer',
            'crumb' =>  array('Customers' => '/customers', 'Show' => '')
        ];

        $transactions = Transaction::leftJoin('tbl_users', 'tbl_users.id', 'tbl_transactions.encoded_by')
        ->select(
            'tbl_transactions.id',
            'tbl_transactions.transaction_date',
            'tbl_transactions.status',

            'tbl_users.full_name as encoder'
        )
        ->where('tbl_transactions.customer_id', $customer->id)
        ->orderBy('tbl_transactions.transaction_date', 'DESC')
        ->get();

        return view('customers.show', compact(
            'page',
            'customer',
            'transactions'
        ));
    }

    public function update(Request $request, $id)
    {
        $customer = Customer::find($id);
        if(!$customer) {
            return back()->withErrors('Customer doesn\'t exist');
        }

        $this->validate($request, [
            'full_name' => 'required',
            'contact_number' => 'required',
            'address' => 'required'
        ]);

        try {
            DB::transaction(function() use ($request, $customer) {
                $customer->full_name = $request->full_name;
                $customer->contact_number = $request->contact_number;
                $customer->address = $request->address;
                $customer->save();
            });

            return back()->withSuccess('Customer information has been updated successfully');

        } catch (\Exception $e) {
            return back()->withInput()->withErrors($e->getMessage());
        }
    }
}
