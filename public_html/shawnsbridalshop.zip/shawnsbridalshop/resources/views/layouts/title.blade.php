<h6 class="font-weight-bolder mb-0">
    {{$page['title']}}
</h6>