<div class="modal fade" role="dialog"  id="create_modal">
    <div class="modal-dialog modal-dialog-top" role="document">
        <div class="modal-content">
            <form method="post" action="/customers/store" class="form">
                @csrf()
                <div class="modal-header">
                    <b class="modal-title bg-pink text-gradient"><i class="fa fa-plus"></i> Add Customer</b>
                    <a class="close text-secondary" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </a>
                </div>
                <div class="modal-body">
                    <div class="row" id="create_body"> 
                        <div class="col-md-12">
                            <label class="bg-pink text-gradient">Personal Information</label><br>
                        </div>
                        <div class="col-md-12">
                            <label class="text-muted">Full name</label> <span class="text-danger">&#x2022;</span>
                            <input type="text" name="full_name" class="form-control" value="{{old('full_name')}}" required />
                        </div>

                        <div class="col-md-12">
                            <label class="text-muted">Contact number</label> <span class="text-danger">&#x2022;</span>
                            <input type="text" class="form-control" name="contact_number" value="{{old('contact_number')}}" required>
                        </div>

                        <div class="col-md-12">
                            <label class="text-muted">Address</label> <span class="text-danger">&#x2022;</span>
                            <textarea class="form-control" name="address" rows="3" required>{{ old('address') }}</textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <a type="button" class="btn bg-gradient-dark" data-dismiss="modal">Close</a>
                    <button type="submit" class="btn bg-pink f-black btn-submit" onclick="return confirm('Are you sure you want to add this customer?')">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>