@extends('layouts.master')

@section('page_name', $page['name'])

@section('page_script')
    <script type="text/javascript" src="/js/customers.js"></script>
@endsection

@section('page_css')

@endsection
@section('content')

    @include('layouts.message')

    <div class="page-header mt-n1 min-height-200 border-radius-xl mt-4" style="background-image: url('/vendor/soft_ui/assets/img/curved-images/curved0.jpg'); background-position-y: 50%;">
        <span class="mask bg-pink opacity-8"></span>
    </div>
    <div class="card card-body blur shadow-blur mx-4 mt-n6 overflow-hidden">
        <div class="row gx-4">
            <div class="col-auto">
                <div class="avatar avatar-xl pt-3 position-relative">
                    <img src="/images/profile-icon2.png" alt="profile_image" class="w-100 border-radius-lg">
                </div>
            </div>
            <div class="col-auto my-auto">
                <div class="h-100">
                    <h5 class="mb-1 btn-edit-customer" 
                        id="{{$customer->id}}" 
                        data-full-name="{{$customer->full_name}}"
                        data-contact-number="{{$customer->contact_number}}"
                        data-address="{{$customer->address}}">
                        {{ $customer->full_name }} &nbsp;&nbsp;&nbsp;<i class="fa fa-pen"></i>
                    </h5>
                    <p class="mb-0 font-weight-bold text-sm"> 
                        Customer
                    </p>
                </div>
            </div>
            
        </div>
    </div>

    <div class="card mb-4 mt-3">
        <div class="card-header pb-0">
            <h6>Transactions Table</h6>
        </div>
        <div class="card-body">
            <table class="table align-items-center mb-0" id="tbl-customers" style="width: 100%;">
                <thead>
                    <tr>
                        <th width="17%" class="text-uppercase text-dark text-xxs font-weight-bolder ps-2">Transaction No.</th>
                        <th class="text-uppercase text-dark text-xxs font-weight-bolder ps-2">Encoder</th> 
                        <th width="20%" class="text-uppercase text-dark text-xxs font-weight-bolder ps-2">Date</th>
                        <th width="11%" class="text-uppercase text-dark text-xxs font-weight-bolder ps-2">Status</th> 
                        <th width="11%" class="text-center text-uppercase text-dark text-xxs font-weight-bolder">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($transactions as $transaction)
                        <tr>

                            <td data-label="Transaction No." class="align-middle header with-label">
                                <span class="text-xs">
                                    {{ $transaction->id }} 
                                </span>
                            </td>
                            <td data-label="Contact Number" class="align-middle header with-label">
                                <span class="text-xs">
                                    {{ $transaction->encoder }}
                                </span>
                            </td>
                            <td data-label="Classification" class="align-middle with-label">
                                <span class="text-xs">
                                    {{ date_format(date_create($transaction->transaction_date), 'F j, Y')  }}
                                </span>
                            </td>
                            <td data-label="Status" class="align-middle with-label">
                                <span class="text-xs">
                                    @if($transaction->status == "Ongoing")
                                        <span class="badge badge-sm bg-gradient-secondary">ongoing</span>
                                    @elseif($transaction->status == "Incomplete")
                                        <span class="badge badge-sm bg-pink">incomplete</span>
                                    @else
                                        <span class="badge badge-sm bg-gradient-success">completed</span>
                                    @endif
                                </span>
                            </td>
                            <td class="align-middle text-center action">
                                <a href="/transactions/{{$transaction->id}}/show" class="icon icon-shape pt-1 icon-sm shadow border-radius-md bg-gradient-dark
                                    text-center align-items-center justify-content-center ">
                                    <i class="fa fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>


    @include('customers.edit')

@endsection