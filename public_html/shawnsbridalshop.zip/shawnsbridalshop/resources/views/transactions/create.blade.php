@extends('layouts.master')
@section('page_name', $page['name'])
@section('page_script')
    <script type="text/javascript" src="/js/transactions.js"></script>
@endsection
@section('page_css')

@endsection

@section('content')

    <div class="row">
        
        <div class="col-md-12">
            @include('layouts.message')
        </div>

        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h6>List of Products</h6>
                </div>
                <div class="card-body">
                    <table class="table align-items-center mb-0" id="tbl-transactions" style="width: 100%;">
                        <thead>
                            <tr>
                                <th width="11%" class="text-uppercase text-dark text-xxs font-weight-bolder ps-2">Product No.</th>
                                <th  class="text-uppercase text-dark text-xxs font-weight-bolder ps-2">Name</th>
                                <th  class="text-uppercase text-dark text-xxs font-weight-bolder ps-2">Description</th>
                                <th width="12%" class="text-uppercase text-dark text-xxs font-weight-bolder ps-2">Category</th>
                                <th width="11%" class="text-uppercase text-dark text-xxs font-weight-bolder ps-2">Sale Price</th> 
                                <th width="11%" class="text-uppercase text-dark text-xxs font-weight-bolder ps-2">Rent Price</th> 
                                {{-- <th width="11%"class="text-uppercase text-dark text-xxs font-weight-bolder ps-2">Rental Deposit</th>  --}}
                                <th width="11%" class="text-center text-uppercase text-dark text-xxs font-weight-bolder">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($products as $product)
                                <tr>
                                    <td data-label="ID" class="align-middle header with-label">
                                        <span class="text-xs">
                                            {{ $product->id }} 
                                        </span>
                                    </td>
                                    <td data-label="Name" class="align-middle header with-label">
                                        <span class="text-xs">
                                            {{ $product->name }} 
                                        </span>
                                    </td>
                                    <td data-label="Description" class="align-middle header with-label">
                                        <span class="text-xs">
                                            {{ $product->description }} 
                                        </span>
                                    </td>
                                    <td data-label="Category" class="align-middle header with-label">
                                        <span class="text-xs">
                                            @if($product->category_id == 1)
                                                {{ "MEN'S" }}
                                            @elseif($product->category_id == 1)
                                                {{ "WOMEN'S" }}
                                            @else
                                                {{ "KID'S" }}
                                            @endif
                                        </span>
                                    </td>
                                    <td data-label="Sale Price" class="align-middle with-label">
                                        <span class="text-xs">
                                            {{ '₱ '.number_format($product->sale_price, 2)  }}
                                        </span>
                                    </td>
                                    <td data-label="Rent Price" class="align-middle with-label">
                                        <span class="text-xs">
                                            {{ '₱ '.number_format($product->rent_price, 2)  }}
                                        </span>
                                    </td>
                                    <td class="td-action" align="center">

                                        <button class="icon icon-shape pt-0 icon-sm shadow border-radius-md bg-gradient-dark
                                        btn-product"
                                            id="{{$product->id}}"
                                            data-name="{{$product->name}}"
                                            data-description="{!! $product->description !!}"
                                            data-for-sale="{{$product->for_sale}}"
                                            data-available-for-rent="{{$product->available_for_rent}}"
                                            data-sale-price="{{$product->sale_price}}"
                                            data-rent-price="{{$product->rent_price}}"
                                            data-damage-deposit="{{$product->damage_deposit}}"
                                            data-sale-price2="{{ '₱ '.number_format($product->sale_price, 2)  }}"
                                            data-rent-price2="{{ '₱ '.number_format($product->rent_price, 2)  }}"
                                            data-damage-deposit2="{{ '₱ '.number_format($product->damage_deposit, 2)  }}"
                                            data-available-for-rent="{{$product->available_for_rent}}"
                                            data-photo="{{$product->activePhoto != '' ? $product->activePhoto->filename : ''}}"
                                        >
                                            <i class="fa fa-plus"></i>
                                        </button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-12" id="transaction-form" style="display: none">
            <form action="/transactions/store" method="POST" id="create-transaction-form">
            @csrf
            <div class="card mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <h6 class="bg-pink text-gradient">Transaction Information</h6>
                        </div>
                        <div class="col-md-6">
                            <label>Customer</label>
                            <select class="form-control select2 select2-create" name="customer" required>
                                <option selected disabled></option>
                                @foreach($customers as $customer)
                                    <option value="{{$customer->id}}" {{ old('customer') == $customer->id ? 'selected' : '' }}>{{$customer->full_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label>Transaction Date</label>
                            <input type="date" value="{{old('transaction_date', date('Y-m-d'))}}" class="form-control" name="transaction_date" required/>
                        </div>
                        <div class="col-md-3">
                            <label>Scheduled Return Date</label>
                            <input type="date" class="form-control" {{old('scheduled_return_date')}} name="scheduled_return_date" id="scheduled_return_date" />
                        </div>
                    </div>
                </div>
            </div>
                <div id="selected-products">

                </div>

                <div align="center">
                    <button type="submit" class="btn bg-gradient-dark" id="btn-save-transaction" onclick="return confirm('Are you sure you want to save this transaction?')">SAVE TRANSACTION</button>
                </div>
            </form>
        </div>
    </div>

    
@endsection