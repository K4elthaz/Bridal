@extends('website.master')

@section('page_css')

@endsection

@section('content')

    <!-- ***** Main Banner Area Start ***** -->
    <div class="page-heading" id="top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-content">
                        <h2>Product Page</h2>
                        <!-- <span>Awesome &amp; Creative HTML CSS layout by TemplateMo</span> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->

    <!-- ***** Product Area Starts ***** -->
    <section class="section" id="product">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                <div class="left-images">
                    @foreach($photos as $photo)
                        <img src="{{ asset('storage/products/' . $photo->filename) }}" alt="">
                    @endforeach
                </div>
            </div>
            <div class="col-lg-8">
                <div class="right-content">
                    <h3>{{ $product->name }}</h3>
                    <span class="price">
                        Sale Price: ₱ {{ number_format($product->sale_price, 2) }} <br>
                        Rent Price: ₱ {{ number_format($product->rent_price, 2) }}
                    </span>
                    <span>{!! nl2br($product->description) !!}</span>
                </div>
            </div>
            </div>
        </div>
    </section>
    <!-- ***** Product Area Ends ***** -->

@endsection